#include <atmel_start.h>
#include "servo.h"
#include "driver_init.h"
#include "utils.h"

#define SPT5435LV_180W_PERIOD_us 3030
#define SPT5435LV_180W_MINIMUM_us 500
#define SPT5435LV_180W_MAXIMUM_us 2500

uint8_t servo_menu_txt[] = "\r\n******** Enter choice ******** \r\n \
1. Back to main menu\r\n \
2. Set servo angle\r\n";

void PWM_example(void)
{	
	// <x> <total period (us)> <duty cycle (0.1%)>
	pwm_set_parameters(&SERVO_PWM, , 5000);
	pwm_enable(&SERVO_PWM);
}

void SERVO_set_angle(int angle)
{
	uint16_t angle_us = SPT5435LV_180W_MINIMUM_us +
			(angle * (SPT5435LV_180W_MAXIMUM_us - SPT5435LV_180W_MINIMUM_us)) / 180.0;
	uint16_t duty_cycle = (uint16_t)((float)(angle_us / SPT5435LV_180W_PERIOD_us) * 10);
	
	pwm_set_parameters(&SERVO_PWM, SPT5435LV_180W_PERIOD_us, duty_cycle);
	pwm_enable(&SERVO_PWM);
}

void SERVO_menu(void)
{
	uint32_t user_selection = 0;
	uint32_t servo_angle	= 0;
	
	while (1) {
		printf("%s", servo_menu_txt);
		
		if (scanf("%d", &user_selection) == 0) {
			/* If its not a number, flush stdin */
			fflush(stdin);
			continue;
		}
		
		printf("\r\nSelected option is %d\r\n", (int)user_selection);
		
		switch (user_selection) {
			case 1:
			printf("\r\nReturning to main menu\r\n");
			return;
			
			case 2:
			printf("\r\nEnter angle >> ");
			scanf("%d", &servo_angle);
			
			if (servo_angle < 0 || servo_angle > 180) {
				printf("%d\r\nERROR: Invalid angle. Angle must be between 0 and 180\r\n", 
					   servo_angle);
				break;
			}
			
			printf("\r\nSetting servo angle to %d\r\n", servo_angle);
			SERVO_set_angle(servo_angle);
			return;
			
			default:
			printf("\r\nInvalid option\r\n");
			break;
		}
	}
}

