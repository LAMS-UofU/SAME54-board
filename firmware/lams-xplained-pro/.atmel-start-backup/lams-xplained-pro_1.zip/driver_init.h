#ifndef DRIVER_INIT_INCLUDED
#define DRIVER_INIT_INCLUDED

#include "atmel_start_pins.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <hal_atomic.h>
#include <hal_delay.h>
#include <hal_gpio.h>
#include <hal_init.h>
#include <hal_io.h>
#include <hal_sleep.h>

#include <hal_usart_sync.h>

#include <hal_mci_sync.h>
#include <hal_pwm.h>
#include <hpl_tc_base.h>

extern struct usart_sync_descriptor LIDAR_USART;
extern struct usart_sync_descriptor STDIO_IO;
extern struct mci_sync_desc SDHC_IO_BUS;
extern struct pwm_descriptor LIDAR_PWM;
extern struct pwm_descriptor SERVO_PWM;

void LIDAR_USART_PORT_init(void);
void LIDAR_USART_CLOCK_init(void);
void LIDAR_USART_init(void);

void STDIO_IO_PORT_init(void);
void STDIO_IO_CLOCK_init(void);
void STDIO_IO_init(void);

void SDHC_IO_BUS_PORT_init(void);
void SDHC_IO_BUS_CLOCK_init(void);
void SDHC_IO_BUS_init(void);

void LIDAR_PWM_PORT_init(void);
void LIDAR_PWM_CLOCK_init(void);
void LIDAR_PWM_init(void);

void SERVO_PWM_PORT_init(void);
void SERVO_PWM_CLOCK_init(void);
void SERVO_PWM_init(void);

void LED0_IO_init(void);
void SW0_IO_init(void);
void CARD_DETECT_0_IO_init(void);
void WRITE_PROTECT_0_IO_init(void);

/**
  * Perform system initialization, initialize pins and clocks for peripherals
  */
void system_init(void);

#ifdef __cplusplus
}
#endif

#endif // DRIVER_INIT_INCLUDED
