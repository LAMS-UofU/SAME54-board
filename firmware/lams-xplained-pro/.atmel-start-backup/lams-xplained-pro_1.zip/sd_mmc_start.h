#ifndef SD_MMC_MAIN_H
#define SD_MMC_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdio.h>

void SDMMC_ACCESS_example(void);

/**
  * Initialize SD MMC Stack
  */
void sd_mmc_stack_init(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* SD_MMC_MAIN_H */
